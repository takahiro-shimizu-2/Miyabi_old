---
name: claude-code-hooks
description: Guide for creating and using hooks in Claude Code. Use when implementing automated workflows triggered by tool events, creating pre/post processing logic, or customizing Claude Code behavior. Triggers include "hooks", "PreToolUse", "PostToolUse", "SessionStart", "automation", "event handlers".
---

# Claude Code Hooks Guide

## Overview

Hooks intercept Claude Code events for custom processing. They execute shell commands at specific points in the workflow.

## Hook Events

| Event | Trigger Point | Use Cases |
|-------|---------------|-----------|
| `PreToolUse` | Before tool execution | Validation, logging, blocking |
| `PostToolUse` | After tool execution | Notifications, transformations |
| `SessionStart` | Session begins | Environment setup, greetings |
| `UserPromptSubmit` | Prompt submitted | Input preprocessing |

## Configuration

### settings.json Structure

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write",
        "command": "bash /path/to/pre-write.sh"
      }
    ],
    "PostToolUse": [
      {
        "matcher": "*",
        "command": "python /path/to/log-tool.py"
      }
    ],
    "SessionStart": [
      {
        "command": "echo 'Session started at $(date)' >> ~/.claude/session.log"
      }
    ]
  }
}
```

## Matcher Patterns

| Pattern | Matches |
|---------|---------|
| `Write` | Write tool only |
| `Write\|Edit` | Write OR Edit tools |
| `Bash(npm*)` | Bash with npm commands |
| `mcp__*` | All MCP tools |
| `mcp__github__*` | GitHub MCP tools |
| `*` | All tools |

## Input/Output Format

### PreToolUse Input (stdin)

```json
{
  "tool": "Write",
  "tool_input": {
    "file_path": "/path/to/file.ts",
    "content": "..."
  },
  "session_id": "abc123"
}
```

### PreToolUse Output (stdout)

```json
{
  "decision": "allow",
  "reason": "File write approved"
}
```

Or to block:

```json
{
  "decision": "block",
  "reason": "Cannot modify protected file"
}
```

### PostToolUse Input (stdin)

```json
{
  "tool": "Write",
  "tool_input": {
    "file_path": "/path/to/file.ts",
    "content": "..."
  },
  "tool_result": {
    "success": true,
    "message": "File written"
  },
  "session_id": "abc123"
}
```

## Example Hooks

### 1. File Write Protection

```bash
#!/bin/bash
# hooks/protect-files.sh - Block writes to critical files

INPUT=$(cat)
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path')

PROTECTED_PATTERNS=(
  "*.lock"
  "*.env"
  ".github/workflows/*"
  "package-lock.json"
)

for pattern in "${PROTECTED_PATTERNS[@]}"; do
  if [[ "$FILE" == $pattern ]]; then
    echo '{"decision": "block", "reason": "Protected file pattern"}'
    exit 0
  fi
done

echo '{"decision": "allow"}'
```

### 2. Auto-Format on Write

```python
#!/usr/bin/env python3
# hooks/auto-format.py - Format files after write

import json
import subprocess
import sys

data = json.load(sys.stdin)
file_path = data.get("tool_input", {}).get("file_path", "")

formatters = {
    ".py": ["black", file_path],
    ".ts": ["prettier", "--write", file_path],
    ".tsx": ["prettier", "--write", file_path],
    ".js": ["prettier", "--write", file_path],
    ".json": ["prettier", "--write", file_path],
}

for ext, cmd in formatters.items():
    if file_path.endswith(ext):
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            print(f"Formatted {file_path}", file=sys.stderr)
        except subprocess.CalledProcessError:
            pass
        break
```

### 3. Slack Notification

```python
#!/usr/bin/env python3
# hooks/notify-slack.py - Notify on important actions

import json
import os
import sys
import requests

data = json.load(sys.stdin)
tool = data.get("tool", "")
result = data.get("tool_result", {})

NOTIFY_TOOLS = ["Write", "Bash", "mcp__github__create_issue"]
WEBHOOK_URL = os.environ.get("SLACK_WEBHOOK")

if tool in NOTIFY_TOOLS and WEBHOOK_URL:
    message = f"🔧 Claude Code executed: {tool}"
    if "file_path" in data.get("tool_input", {}):
        message += f"\nFile: {data['tool_input']['file_path']}"
    
    requests.post(WEBHOOK_URL, json={"text": message})
```

### 4. Session Logging

```bash
#!/bin/bash
# hooks/session-log.sh - Log all tool usage

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool')
TIMESTAMP=$(date -Iseconds)
SESSION=$(echo "$INPUT" | jq -r '.session_id')

LOG_DIR="$HOME/.claude/logs"
mkdir -p "$LOG_DIR"

echo "[$TIMESTAMP] [$SESSION] Tool: $TOOL" >> "$LOG_DIR/tools.log"
echo "$INPUT" | jq -c >> "$LOG_DIR/tools-detail.jsonl"
```

## MCP Tool Hooks

Match MCP tools using `mcp__<server>__<tool>` pattern:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "mcp__github__create_issue",
        "command": "python validate-issue.py"
      },
      {
        "matcher": "mcp__github__*",
        "command": "bash log-github-ops.sh"
      }
    ]
  }
}
```

## Configuration Locations

| Scope | File | Use Case |
|-------|------|----------|
| User | `~/.claude/settings.json` | Personal hooks |
| Project | `.claude/settings.json` | Team hooks |
| Local | `.claude/settings.local.json` | Personal overrides |

## Best Practices

1. **Fast Execution**: Hooks block Claude Code - keep them quick
2. **Error Handling**: Always output valid JSON
3. **Logging**: Log to files, not stdout (interferes with output)
4. **Idempotency**: Hooks may run multiple times
5. **Testing**: Test hooks independently before deploying

## Debugging

```bash
# Test hook manually
echo '{"tool": "Write", "tool_input": {"file_path": "test.ts"}}' | \
  bash hooks/protect-files.sh

# Enable verbose logging
export CLAUDE_HOOKS_DEBUG=1
claude
```
