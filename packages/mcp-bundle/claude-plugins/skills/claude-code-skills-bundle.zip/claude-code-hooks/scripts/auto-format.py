#!/usr/bin/env python3
"""
hooks/auto-format.py
PostToolUse hook to auto-format files after write operations.

Usage: Add to settings.json:
{
  "hooks": {
    "PostToolUse": [
      {"matcher": "Write", "command": "python ~/.claude/hooks/auto-format.py"}
    ]
  }
}

Requirements:
- black (pip install black)
- prettier (npm install -g prettier)
- gofmt (included with Go)
- rustfmt (rustup component add rustfmt)
"""

import json
import subprocess
import sys
import shutil
from pathlib import Path


def format_file(file_path: str) -> tuple[bool, str]:
    """Format a file based on its extension. Returns (success, message)."""
    
    path = Path(file_path)
    ext = path.suffix.lower()
    
    # Define formatters for each extension
    formatters = {
        # Python
        '.py': ['black', '--quiet', file_path],
        
        # JavaScript/TypeScript (Prettier)
        '.js': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.jsx': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.ts': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.tsx': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.mjs': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.cjs': ['prettier', '--write', '--loglevel', 'error', file_path],
        
        # Web (Prettier)
        '.json': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.css': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.scss': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.html': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.md': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.yaml': ['prettier', '--write', '--loglevel', 'error', file_path],
        '.yml': ['prettier', '--write', '--loglevel', 'error', file_path],
        
        # Go
        '.go': ['gofmt', '-w', file_path],
        
        # Rust
        '.rs': ['rustfmt', file_path],
    }
    
    cmd = formatters.get(ext)
    if not cmd:
        return True, f"No formatter configured for {ext}"
    
    # Check if formatter is available
    formatter = cmd[0]
    if not shutil.which(formatter):
        return True, f"Formatter '{formatter}' not found, skipping"
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            return True, f"Formatted {file_path} with {formatter}"
        else:
            return False, f"Format failed: {result.stderr}"
            
    except subprocess.TimeoutExpired:
        return False, f"Format timeout for {file_path}"
    except Exception as e:
        return False, f"Format error: {str(e)}"


def main():
    # Read hook input from stdin
    try:
        data = json.load(sys.stdin)
    except json.JSONDecodeError:
        print("Invalid JSON input", file=sys.stderr)
        return
    
    # Extract file path from tool input
    tool_input = data.get('tool_input', {})
    file_path = tool_input.get('file_path', '')
    
    if not file_path:
        return
    
    # Check if file exists
    if not Path(file_path).exists():
        print(f"File not found: {file_path}", file=sys.stderr)
        return
    
    # Format the file
    success, message = format_file(file_path)
    
    # Log result (to stderr to avoid interfering with hook output)
    print(message, file=sys.stderr)


if __name__ == '__main__':
    main()
