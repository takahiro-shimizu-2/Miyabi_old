#!/bin/bash
# hooks/protect-files.sh
# PreToolUse hook to block writes to protected files
# 
# Usage: Add to settings.json:
# {
#   "hooks": {
#     "PreToolUse": [
#       {"matcher": "Write", "command": "bash ~/.claude/hooks/protect-files.sh"}
#     ]
#   }
# }

set -e

# Read input from stdin
INPUT=$(cat)

# Extract file path from tool input
FILE=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

if [ -z "$FILE" ]; then
    echo '{"decision": "allow"}'
    exit 0
fi

# Define protected patterns
PROTECTED_PATTERNS=(
    "*.lock"
    "*.env"
    "*.env.*"
    ".github/workflows/*"
    "package-lock.json"
    "yarn.lock"
    "pnpm-lock.yaml"
    "Cargo.lock"
    ".git/*"
    "node_modules/*"
    "__pycache__/*"
    "*.pyc"
    ".DS_Store"
)

# Check against protected patterns
for pattern in "${PROTECTED_PATTERNS[@]}"; do
    if [[ "$FILE" == $pattern ]]; then
        echo "{\"decision\": \"block\", \"reason\": \"File matches protected pattern: $pattern\"}"
        exit 0
    fi
done

# Check for specific directories
PROTECTED_DIRS=(
    ".git"
    "node_modules"
    "__pycache__"
    ".venv"
    "venv"
)

for dir in "${PROTECTED_DIRS[@]}"; do
    if [[ "$FILE" == "$dir/"* ]]; then
        echo "{\"decision\": \"block\", \"reason\": \"Cannot modify files in protected directory: $dir\"}"
        exit 0
    fi
done

# Allow all other files
echo '{"decision": "allow"}'
