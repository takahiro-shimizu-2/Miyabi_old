---
name: claude-code-subagent
description: Guide for creating and managing sub-agents in Claude Code. Use when building specialized AI assistants for specific tasks, creating reusable agent workflows, or delegating tasks automatically. Triggers include "sub-agent", "create agent", "claude code agent", "specialized assistant", "auto-delegation", "agent YAML".
---

# Claude Code Sub-Agent Guide

## Overview

Sub-agents are specialized AI assistants defined as YAML-frontmatter Markdown files. Claude Code automatically delegates appropriate tasks to sub-agents based on their descriptions.

## File Locations

| Scope | Path | Sharing |
|-------|------|---------|
| User | `~/.claude/agents/` | All projects |
| Project | `.claude/agents/` | Git-shared with team |

## Sub-Agent Structure

```markdown
---
name: code-reviewer
description: >
  Expert code review agent. Use PROACTIVELY for PR reviews,
  security audits, and code quality checks.
tools:
  - Read
  - Grep
  - Glob
model: sonnet
---

# Code Review Agent

You are an expert code reviewer specializing in:
- Security vulnerabilities
- Performance optimization
- Code style and best practices

## Review Process

1. Analyze file structure and dependencies
2. Check for security issues (injection, auth flaws)
3. Evaluate performance patterns
4. Review error handling
5. Assess test coverage

## Output Format

Provide structured feedback:
- 🔴 Critical issues (must fix)
- 🟡 Warnings (should fix)
- 🟢 Suggestions (nice to have)
```

## Configuration Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Agent identifier |
| `description` | Yes | Auto-delegation trigger (include "PROACTIVELY" for aggressive matching) |
| `tools` | No | Tool allowlist (omit for all tools) |
| `model` | No | `sonnet`, `opus`, `haiku`, or `inherit` |

## Tool Restrictions

Limit tools for security and focus:

```yaml
tools:
  - Read      # Read files
  - Grep      # Search patterns
  - Glob      # Find files
  - Write     # Modify files
  - Bash      # Run commands
  - mcp__github__*  # GitHub MCP tools only
```

## Example Agents

### Documentation Writer

```markdown
---
name: docs-writer
description: >
  Technical documentation specialist. Use PROACTIVELY for
  README updates, API docs, and code comments.
tools:
  - Read
  - Write
  - Glob
model: sonnet
---

# Documentation Writer

Create clear, structured documentation following:
- Clear headings and sections
- Code examples with proper formatting
- API reference format for functions
- Installation and usage guides
```

### Test Generator

```markdown
---
name: test-generator
description: >
  Test case generator. Use PROACTIVELY for unit tests,
  integration tests, and test coverage improvement.
tools:
  - Read
  - Write
  - Bash
  - Glob
model: sonnet
---

# Test Generator

Generate comprehensive tests:
- Unit tests for individual functions
- Integration tests for modules
- Edge cases and error scenarios
- Use project's testing framework
```

### Security Auditor

```markdown
---
name: security-auditor
description: >
  Security vulnerability scanner. Use PROACTIVELY for
  security reviews, dependency audits, OWASP checks.
tools:
  - Read
  - Grep
  - Glob
  - Bash
model: opus
---

# Security Auditor

Audit code for:
- OWASP Top 10 vulnerabilities
- Hardcoded secrets and credentials
- SQL/Command injection risks
- Authentication/Authorization flaws
- Dependency vulnerabilities (npm audit, pip-audit)
```

## Best Practices

1. **Clear Descriptions**: Include "use PROACTIVELY" for automatic delegation
2. **Minimal Tools**: Restrict to only needed tools
3. **Version Control**: Commit project agents to git
4. **Model Selection**: Use `haiku` for fast tasks, `opus` for complex analysis
5. **Focused Scope**: One agent per specialized domain

## CLI Integration

```bash
# List available agents
claude --agents

# Use specific agent
claude --agent security-auditor "Review auth module"

# Define inline agent (headless mode)
claude -p "Review code" --agents '
- name: quick-review
  description: Fast code review
  tools: [Read, Grep]
  model: haiku
'
```

## Delegation Flow

```
User Request → Claude Code
                 ↓
        Analyze description matches
                 ↓
        [Match Found] → Delegate to Sub-Agent
                 ↓
        Sub-Agent executes with restricted tools
                 ↓
        Return results to main session
```
