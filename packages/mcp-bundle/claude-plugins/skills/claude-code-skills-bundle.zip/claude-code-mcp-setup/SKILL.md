---
name: claude-code-mcp-setup
description: Guide for configuring MCP (Model Context Protocol) servers in Claude Code. Use when setting up MCP integrations, connecting external tools (JIRA, Sentry, GitHub, databases), configuring server scopes (user/project/local), or troubleshooting MCP connections. Triggers include "claude code MCP", "MCP setup", "connect external tools", "MCP server configuration", "claude mcp add".
---

# Claude Code MCP Setup Guide

## Overview

Claude Code connects to 100+ external tools via MCP (Model Context Protocol). This skill covers installation, configuration, and management of MCP servers.

## Installation Scopes

| Scope | Location | Shared | Use Case |
|-------|----------|--------|----------|
| **User** | `~/.claude/settings.json` | No | Personal tools (all projects) |
| **Project** | `.claude/settings.json` | Yes (git) | Team-shared tools |
| **Local** | `.claude/settings.local.json` | No | Personal project overrides |

## Quick Commands

```bash
# Add MCP server
claude mcp add <name> -s user|project -- <command> [args]

# List configured servers
claude mcp list

# Remove server
claude mcp remove <name> -s user|project

# Check status (inside Claude Code)
/mcp
```

## Server Types

### 1. stdio Servers (Local)

Standard subprocess communication:

```bash
# NPM package server
claude mcp add memory -s user -- npx -y @anthropic-ai/memory-mcp

# Python server
claude mcp add my-tool -s project -- python /path/to/server.py

# Docker container
claude mcp add postgres -s project -- docker run -i postgres-mcp
```

### 2. SSE/HTTP Servers (Remote)

URL-based remote servers:

```bash
# Add SSE server
claude mcp add remote-api -s user --url https://api.example.com/mcp/sse

# With authentication
export MCP_API_KEY="your-key"
claude mcp add secure-api -s user --url https://api.example.com/mcp/sse
```

## Configuration Format

### settings.json Structure

```json
{
  "mcpServers": {
    "memory": {
      "command": "npx",
      "args": ["-y", "@anthropic-ai/memory-mcp"],
      "env": {}
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "ghp_xxxx"
      }
    },
    "remote-api": {
      "type": "sse",
      "url": "https://api.example.com/mcp/sse",
      "headers": {
        "Authorization": "Bearer ${MCP_API_KEY}"
      }
    }
  }
}
```

## Popular MCP Servers

| Server | Command | Use Case |
|--------|---------|----------|
| Memory | `npx -y @anthropic-ai/memory-mcp` | Knowledge graph persistence |
| GitHub | `npx -y @modelcontextprotocol/server-github` | Repo management |
| Filesystem | `npx -y @modelcontextprotocol/server-filesystem /path` | File access |
| PostgreSQL | `npx -y @modelcontextprotocol/server-postgres` | Database queries |
| Brave Search | `npx -y @modelcontextprotocol/server-brave-search` | Web search |

## Environment Variables

```bash
# Set in shell profile or .env
export GITHUB_TOKEN="ghp_xxx"
export ANTHROPIC_API_KEY="sk-ant-xxx"
export MCP_SERVER_DEBUG="1"  # Enable debug logging
```

Or configure in settings.json:

```json
{
  "mcpServers": {
    "myserver": {
      "command": "node",
      "args": ["server.js"],
      "env": {
        "API_KEY": "${API_KEY}"  // Reference env var
      }
    }
  }
}
```

## Troubleshooting

### Check Connection Status

```
/mcp
```

Shows: connected servers, available tools, connection errors.

### Common Issues

1. **Server not starting**: Check command path and permissions
2. **Authentication failed**: Verify env vars are set
3. **Tools not appearing**: Restart Claude Code after config changes
4. **Timeout errors**: Check network connectivity for remote servers

### Debug Mode

```bash
# Enable debug logging
MCP_SERVER_DEBUG=1 claude

# Check logs
cat ~/.claude/logs/mcp-*.log
```

## Security Notes

- MCP servers run with full system access - use trusted sources only
- Third-party servers are **user responsibility**
- Review server code before installation
- Use project-scoped servers for team tools
- Local scope for sensitive personal credentials
