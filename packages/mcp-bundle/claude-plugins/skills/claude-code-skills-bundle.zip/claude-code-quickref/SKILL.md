---
name: claude-code-quickref
description: Quick reference card for Claude Code commands, shortcuts, and configurations. Use when needing fast lookup of CLI flags, slash commands, keyboard shortcuts, file locations, or configuration options. Triggers include "claude code reference", "quick reference", "cheat sheet", "command list", "shortcuts", "CLI reference".
---

# Claude Code Quick Reference

## Installation

```bash
# macOS/Linux
curl -fsSL https://claude.ai/install.sh | bash

# Windows (via WSL)
wsl
curl -fsSL https://claude.ai/install.sh | bash

# Start
cd your-project && claude
```

## CLI Flags

| Flag | Description |
|------|-------------|
| `-p, --print` | Non-interactive mode |
| `-c, --continue` | Resume last conversation |
| `-r, --resume` | Select conversation to resume |
| `-m, --model` | Model: opus/sonnet/haiku |
| `-s, --permission-mode` | default/auto-edit/full-auto |
| `--output-format` | text/json/stream-json |
| `--allowedTools` | Restrict available tools |
| `-C, --cwd` | Working directory |
| `--agents` | Custom sub-agents (YAML) |
| `--append-system-prompt` | Add to system prompt |
| `--system-prompt` | Override system prompt |

## Slash Commands

| Command | Action |
|---------|--------|
| `/help` | Show help |
| `/model` | Switch model |
| `/cost` | View token usage |
| `/compact` | Compress context |
| `/clear` | Reset context |
| `/config` | Open settings |
| `/mcp` | MCP server status |
| `/bug` | Report issue |
| `/plan` | Toggle plan mode (read-only) |
| `/output-style` | Change output format |

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl+C` | Cancel current operation |
| `Ctrl+D` | Exit Claude Code |
| `Ctrl+L` | Clear screen |
| `↑/↓` | Navigate history |
| `Tab` | Autocomplete |
| `Esc` | Cancel input |

## Extended Thinking Triggers

| Phrase | Depth |
|--------|-------|
| "think" | Basic |
| "think hard" | Deep |
| "think more" | Deeper |
| "think a lot" | Maximum |

## File Locations

| Purpose | Path |
|---------|------|
| User settings | `~/.claude/settings.json` |
| Project settings | `.claude/settings.json` |
| Local settings | `.claude/settings.local.json` |
| Memory | `CLAUDE.md` (root, subdirs, ~/.claude/) |
| User agents | `~/.claude/agents/` |
| Project agents | `.claude/agents/` |
| User commands | `~/.claude/commands/` |
| Project commands | `.claude/commands/` |
| Skills | `~/.claude/skills/`, `.claude/skills/` |
| Logs | `~/.claude/logs/` |
| Sessions | `~/.claude/sessions/` |

## MCP Commands

```bash
# Add server
claude mcp add <n> -s user -- <command>

# List servers
claude mcp list

# Remove server
claude mcp remove <n> -s user

# Check status (inside Claude)
/mcp
```

## Permission Modes

| Mode | File Edits | Commands | Sandbox |
|------|-----------|----------|---------|
| default | Approval | Approval | Full |
| auto-edit | Auto | Approval | Full |
| full-auto | Auto | Auto | Limited |

## Authentication

```bash
# Login
claude auth login

# Logout
claude auth logout

# Status
claude auth status

# Bedrock
export CLAUDE_CODE_USE_BEDROCK=1
export AWS_REGION=us-east-1

# Vertex
export CLAUDE_CODE_USE_VERTEX=1
export CLOUD_ML_REGION=us-central1
```

## Cost Management

- Average: $100-200/dev/month (Sonnet)
- `/cost` - View session usage
- `/compact` - Manual compaction
- `/clear` - Reset between tasks
- Auto-compact at 95% context

## Image Input

- Drag & drop image files
- Copy & paste from clipboard
- Reference path: `/path/to/image.png`

## settings.json Template

```json
{
  "permissions": {
    "allow": ["Read", "Write"],
    "deny": ["Bash(rm -rf *)"]
  },
  "mcpServers": {
    "memory": {
      "command": "npx",
      "args": ["-y", "@anthropic-ai/memory-mcp"]
    }
  },
  "hooks": {
    "PostToolUse": [
      {"matcher": "*", "command": "logger.sh"}
    ]
  }
}
```

## Sub-Agent Template

```yaml
---
name: agent-name
description: Use PROACTIVELY for...
tools: [Read, Write, Grep]
model: sonnet
---

# Agent Instructions
Your specialized instructions here.
```
