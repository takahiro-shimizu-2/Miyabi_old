---
name: claude-code-troubleshooting
description: Guide for troubleshooting Claude Code issues. Use when encountering installation errors, authentication failures, performance problems, context limits, MCP connection issues, or unexpected behavior. Triggers include "claude code error", "troubleshooting", "not working", "connection failed", "context limit", "rate limit", "debugging".
---

# Claude Code Troubleshooting Guide

## Quick Diagnostics

```bash
# Check installation
which claude
claude --version

# Check authentication
claude auth status

# Check MCP servers
/mcp  # Inside Claude Code

# View session cost
/cost

# Clear context
/clear
```

## Common Issues

### 1. Installation Failures

**macOS/Linux:**
```bash
# Reinstall
curl -fsSL https://claude.ai/install.sh | bash

# Check PATH
echo $PATH | grep -q '.claude/bin' || \
  echo 'export PATH="$HOME/.claude/bin:$PATH"' >> ~/.zshrc

# Verify Node.js (required)
node --version  # Should be 18+
```

**Windows (WSL):**
```bash
# Install in WSL, not PowerShell
wsl
curl -fsSL https://claude.ai/install.sh | bash
```

### 2. Authentication Errors

```bash
# Re-authenticate
claude auth logout
claude auth login

# Check API key (for Console users)
echo $ANTHROPIC_API_KEY

# Verify Bedrock setup
echo $CLAUDE_CODE_USE_BEDROCK
echo $AWS_REGION
aws sts get-caller-identity

# Verify Vertex setup
echo $CLAUDE_CODE_USE_VERTEX
echo $CLOUD_ML_REGION
gcloud auth application-default print-access-token
```

### 3. Context Limit Issues

**Symptoms:** Slow responses, "context too long" errors

```bash
# View current usage
/cost

# Manual compaction
/compact

# Clear and restart
/clear

# Auto-compact triggers at 95% capacity
```

**Prevention:**
- Use `/clear` between unrelated tasks
- Break large tasks into smaller steps
- Reference files instead of pasting content

### 4. MCP Connection Failures

```bash
# Check server status
/mcp

# List configured servers
claude mcp list

# Remove and re-add server
claude mcp remove <name> -s user
claude mcp add <name> -s user -- <command>

# Test server directly
npx -y @modelcontextprotocol/inspector <command>
```

**Debug MCP:**
```bash
# Enable debug logging
export MCP_SERVER_DEBUG=1
claude

# Check logs
ls ~/.claude/logs/mcp-*.log
tail -f ~/.claude/logs/mcp-*.log
```

### 5. Rate Limits

**Symptoms:** "Rate limit exceeded", slow responses

```bash
# Check with /cost for token usage
/cost

# Solutions:
# 1. Wait 1-5 minutes
# 2. Use smaller model
/model haiku

# 3. Reduce token usage
/compact
/clear
```

**Recommended limits:**
- TPM: 80,000+ tokens/min
- RPM: 2,000+ requests/min

### 6. File Permission Errors

```bash
# Check Claude Code permissions
cat ~/.claude/settings.json | jq '.permissions'

# Reset permissions
rm ~/.claude/settings.json
claude  # Will recreate with defaults

# Project-specific permissions
cat .claude/settings.json
```

### 7. Git Integration Issues

```bash
# Verify git config
git config --list

# Check SSH keys
ssh -T git@github.com

# Git credentials
git config --global credential.helper store
```

### 8. Performance Issues

**Slow responses:**
```bash
# Check network
curl -I https://api.anthropic.com

# Reduce context
/compact
/clear

# Use faster model
/model haiku
```

**High memory usage:**
```bash
# Restart Claude Code
exit
claude

# Clear all sessions
rm -rf ~/.claude/sessions/*
```

## Log Locations

| Log | Path | Purpose |
|-----|------|---------|
| General | `~/.claude/logs/claude.log` | Main activity log |
| MCP | `~/.claude/logs/mcp-*.log` | MCP server logs |
| Sessions | `~/.claude/sessions/` | Session history |
| Settings | `~/.claude/settings.json` | User configuration |

## Environment Variables

```bash
# Disable telemetry
export DISABLE_TELEMETRY=1

# Disable error reporting
export DISABLE_ERROR_REPORTING=1

# Custom API endpoint
export ANTHROPIC_API_URL=https://custom.endpoint.com

# Bedrock configuration
export CLAUDE_CODE_USE_BEDROCK=1
export AWS_REGION=us-east-1

# Vertex configuration
export CLAUDE_CODE_USE_VERTEX=1
export CLOUD_ML_REGION=us-central1
```

## Reset and Recovery

```bash
# Full reset (preserves history)
mv ~/.claude/settings.json ~/.claude/settings.json.bak
claude

# Complete reinstall
rm -rf ~/.claude
curl -fsSL https://claude.ai/install.sh | bash

# Clear all sessions
rm -rf ~/.claude/sessions/*

# Report bug
/bug
```

## Getting Help

```bash
# Built-in help
claude --help
claude auth --help
claude mcp --help

# Report issues
/bug  # Inside Claude Code

# Documentation
# https://code.claude.com/docs
```

## Checklist for Support

When reporting issues, include:

1. Claude Code version: `claude --version`
2. OS and version: `uname -a` or `systeminfo`
3. Node.js version: `node --version`
4. Authentication method (App/Console/Bedrock/Vertex)
5. Error message (exact text)
6. Steps to reproduce
7. Relevant log entries
