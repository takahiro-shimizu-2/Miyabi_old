---
name: claude-code-ci-cd
description: Guide for integrating Claude Code into CI/CD pipelines. Use when setting up GitHub Actions, GitLab CI/CD, or headless automation for code generation, PR reviews, or automated fixes. Triggers include "GitHub Actions", "GitLab CI", "CI/CD", "headless mode", "automated code review", "PR automation".
---

# Claude Code CI/CD Integration

## Overview

Run Claude Code programmatically in CI/CD pipelines for automated code generation, PR reviews, and issue resolution.

## Headless Mode Basics

```bash
# Print mode (non-interactive)
claude -p "task description" --output-format json

# Permission modes
claude -p "task" --permission-mode default    # All approvals
claude -p "task" --permission-mode auto-edit  # Auto file edits
claude -p "task" --permission-mode full-auto  # No approvals (sandboxed)

# Output formats
claude -p "task" --output-format text       # Plain text
claude -p "task" --output-format json       # JSON with metadata
claude -p "task" --output-format stream-json # Streaming JSON
```

## GitHub Actions

### Basic Workflow

```yaml
name: Claude Code Review
on:
  pull_request:
    types: [opened, synchronize]

jobs:
  review:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: write
    
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      
      - name: Install Claude Code
        run: curl -fsSL https://claude.ai/install.sh | bash
      
      - name: Review PR
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          claude -p "Review the changes in this PR and provide feedback on:
          - Code quality
          - Potential bugs
          - Performance issues
          - Security concerns
          
          Files changed:
          $(git diff --name-only ${{ github.event.pull_request.base.sha }})" \
          --permission-mode default \
          --output-format json > review.json
      
      - name: Post Review Comment
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const review = JSON.parse(fs.readFileSync('review.json', 'utf8'));
            github.rest.issues.createComment({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: context.issue.number,
              body: review.result
            });
```

### Auto-Fix on Issue

```yaml
name: Claude Auto-Fix
on:
  issues:
    types: [labeled]

jobs:
  fix:
    if: github.event.label.name == 'claude-fix'
    runs-on: ubuntu-latest
    permissions:
      contents: write
      pull-requests: write
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Install Claude Code
        run: curl -fsSL https://claude.ai/install.sh | bash
      
      - name: Apply Fix
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          claude -p "Fix the issue described: ${{ github.event.issue.title }}
          
          Details: ${{ github.event.issue.body }}" \
          --permission-mode auto-edit
      
      - name: Create PR
        uses: peter-evans/create-pull-request@v6
        with:
          title: "fix: ${{ github.event.issue.title }}"
          body: "Automated fix for #${{ github.event.issue.number }}"
          branch: "claude-fix-${{ github.event.issue.number }}"
```

## GitLab CI/CD

### Basic Pipeline

```yaml
stages:
  - review
  - fix

variables:
  ANTHROPIC_API_KEY: $ANTHROPIC_API_KEY

.claude_setup: &claude_setup
  before_script:
    - curl -fsSL https://claude.ai/install.sh | bash
    - export PATH="$HOME/.claude/bin:$PATH"

code_review:
  <<: *claude_setup
  stage: review
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  script: |
    claude -p "Review the merge request changes:
    $(git diff $CI_MERGE_REQUEST_DIFF_BASE_SHA)" \
    --permission-mode default \
    --output-format json > review.json
  artifacts:
    paths:
      - review.json

auto_fix:
  <<: *claude_setup
  stage: fix
  rules:
    - if: $CI_COMMIT_MESSAGE =~ /\[claude-fix\]/
  script: |
    FIX_DESC=$(echo "$CI_COMMIT_MESSAGE" | sed 's/\[claude-fix\]//')
    claude -p "Apply fix: $FIX_DESC" \
    --permission-mode auto-edit
    git add -A
    git commit -m "fix: Applied Claude fix" || true
    git push origin HEAD:$CI_COMMIT_REF_NAME
```

## SDK Integration (TypeScript)

```typescript
import Anthropic from "@anthropic-ai/sdk";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);
const client = new Anthropic();

async function runClaudeCode(task: string): Promise<string> {
  // Using SDK for conversation management
  const { stdout } = await execAsync(
    `claude -p "${task}" --permission-mode full-auto --output-format json`
  );
  return JSON.parse(stdout).result;
}

// Example: Automated issue processing
async function processIssue(issue: { title: string; body: string }) {
  const result = await runClaudeCode(`
    Analyze and fix the following issue:
    Title: ${issue.title}
    Description: ${issue.body}
    
    Apply the necessary code changes.
  `);
  
  return result;
}
```

## Environment Variables

```bash
# Required
ANTHROPIC_API_KEY=sk-ant-xxx

# Optional
CLAUDE_MODEL=claude-sonnet-4-5-20250929
DISABLE_TELEMETRY=1
DISABLE_ERROR_REPORTING=1

# For Bedrock
CLAUDE_CODE_USE_BEDROCK=1
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx

# For Vertex AI
CLAUDE_CODE_USE_VERTEX=1
CLOUD_ML_REGION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json
```

## Best Practices

1. **Limit Permissions**: Use `default` or `auto-edit` modes in CI
2. **Timeouts**: Set appropriate job timeouts (Claude tasks can take minutes)
3. **Cost Control**: Use token limits and smaller models for reviews
4. **Caching**: Cache Claude Code installation
5. **Secrets**: Never expose API keys in logs

## Rate Limiting

```yaml
# GitHub Actions with rate limiting
- name: Rate Limit Check
  run: |
    if [ $(gh api rate_limit --jq '.rate.remaining') -lt 100 ]; then
      echo "Rate limit low, waiting..."
      sleep 60
    fi
```

## Output Parsing

```bash
# Extract result from JSON output
claude -p "task" --output-format json | jq -r '.result'

# Check for errors
if ! claude -p "task" --output-format json > result.json 2>&1; then
  echo "Claude Code failed"
  cat result.json
  exit 1
fi
```
